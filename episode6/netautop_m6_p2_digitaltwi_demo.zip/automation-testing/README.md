CICD Pipeline 

1. Installation of Docker 
2. Installation of Containerlab
3. Installation of Nautobot : In progress
4. Containerlab Topology : In progress

