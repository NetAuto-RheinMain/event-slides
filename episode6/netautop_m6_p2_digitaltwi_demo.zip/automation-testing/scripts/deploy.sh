#!/bin/bash

set -e

CLAB_NAME="digital-twin"
TOPOLOGY_FILE="topology.clab.yml"
SUDO_PASS="$1"

echo "======================================"
echo "Containerlab Deployment Script"
echo "======================================"

# Check if containerlab is installed
if ! command -v containerlab &> /dev/null; then
    echo "Error: containerlab is not installed"
    exit 1
fi

echo "✓ Containerlab is installed"

# Check if topology file exists
if [ ! -f "$TOPOLOGY_FILE" ]; then
    echo "Error: $TOPOLOGY_FILE not found"
    exit 1
fi

echo "✓ Topology file found"

# Check if lab already exists and destroy it
if echo "$SUDO_PASS" | sudo -S containerlab inspect --name "$CLAB_NAME" &> /dev/null; then
    echo "⚠ Existing lab found. Destroying..."
    echo "$SUDO_PASS" | sudo -S containerlab destroy --name "$CLAB_NAME" --cleanup
    echo "✓ Existing lab destroyed"
fi






# Deploy the lab
echo "📦 Deploying containerlab: $CLAB_NAME"
echo "$SUDO_PASS" | sudo -S containerlab deploy --topo "$TOPOLOGY_FILE"



# Check deployment status
if [ $? -eq 0 ]; then
    echo "======================================"
    echo "✅ Deployment successful!"
    echo "======================================"

    # Display lab information
    echo ""
    echo "Lab Information:"
    echo "$SUDO_PASS" | sudo -S containerlab inspect --name "$CLAB_NAME"

    # Provision SSH keys (wait for nodes to stabilize first)
    echo ""
    echo "⏳ Waiting for nodes to stabilize (30 seconds)..."
    sleep 30

    echo "🔑 Provisioning SSH keys..."
    if [ -f "scripts/provision-ssh.sh" ]; then
        bash scripts/provision-ssh.sh "$HOME/.ssh/id_rsa.pub" || echo "⚠️ SSH provisioning skipped (keys may need manual setup)"
    fi

    echo ""
    echo "To access nodes, use:"
    echo "  docker exec -it clab-${CLAB_NAME}-<node-name> bash"

else
    echo "❌ Deployment failed!"
    exit 1
fi
