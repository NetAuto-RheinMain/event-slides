#!/usr/bin/env python3
"""
NETCONF Configuration Push with Backup & Rollback
Supports Arista cEOS (OpenConfig) and Cisco CSR1000v (IOS-XE native YANG).
"""

import sys
import os
import re
from datetime import datetime
from ncclient import manager
from ncclient.transport.errors import SessionCloseError
from ncclient.operations.errors import TimeoutExpiredError

BACKUP_DIR = "/tmp/netconf_backups"


# ─────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────

def ensure_backup_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


def is_cisco(host):
    return "cisco" in host or "10.7" in host


def get_backup_filename(host):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    git_hash = os.popen("git rev-parse --short HEAD 2>/dev/null").read().strip() or "no-git"
    return f"{BACKUP_DIR}/{host}_backup_{timestamp}_{git_hash}.xml"


def log_action(host, action, details):
    ensure_backup_dir()
    log_file = f"{BACKUP_DIR}/{host}_push_log.txt"
    with open(log_file, "a") as f:
        f.write(f"{datetime.now().isoformat()} | {action} | {details}\n")


def connect(host, username, password):
    return manager.connect(
        host=host,
        port=830,
        username=username,
        password=password,
        hostkey_verify=False,
        allow_agent=False,
        look_for_keys=False,
        timeout=60,
    )


# ─────────────────────────────────────────
# BACKUP
# ─────────────────────────────────────────

def backup_config(m, host):
    """
    Fetch running interface config and save as a rollback-ready XML file.

    Arista cEOS  → OpenConfig interfaces namespace
    Cisco CSR    → IOS-XE native namespace

    The saved file is a valid NETCONF <config> payload that can be fed
    directly back into edit_config during rollback.
    """
    print(f"  📥 Taking backup from {host}...")

    try:
        if is_cisco(host):
            cisco_filter = (
                '<native xmlns="http://cisco.com/ns/yang/Cisco-IOS-XE-native">'
                "<interface/>"
                "</native>"
            )
            result = m.get_config(source="running", filter=("subtree", cisco_filter))
        else:
            arista_filter = (
                '<interfaces xmlns="http://openconfig.net/yang/interfaces">'
                "<interface/>"
                "</interfaces>"
            )
            result = m.get_config(source="running", filter=("subtree", arista_filter))

        raw = result.xml

        # Extract the inner payload from <data>...</data> and re-wrap as <config>
        # so the backup file is immediately usable as an edit_config payload.
        match = re.search(r"<data[^>]*>(.*?)</data>", raw, re.DOTALL)
        inner = match.group(1).strip() if match else ""

        if not inner:
            print(f"  ⚠️  Empty config response for {host} — nothing to back up.")
            return None

        config_out = (
            '<config xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"'
            ' xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">\n'
            f"{inner}\n"
            "</config>"
        )

        backup_file = get_backup_filename(host)
        with open(backup_file, "w") as f:
            f.write(config_out)

        size = os.path.getsize(backup_file)
        print(f"  ✅ Backup saved: {os.path.basename(backup_file)} ({size} bytes)")
        return backup_file

    except Exception as e:
        print(f"  ⚠️  Backup failed for {host}: {e}")
        return None


# ─────────────────────────────────────────
# PUSH
# ─────────────────────────────────────────

def push_config(host, username, password, xml_file):
    ensure_backup_dir()

    if not os.path.exists(xml_file):
        print(f"❌ XML file not found: {xml_file}")
        return False

    with open(xml_file) as f:
        config = f.read()

    print(f"\n📤 PUSH CONFIG → {host}")

    try:
        with connect(host, username, password) as m:
            # Always back up BEFORE pushing so we can roll back on failure
            backup_file = backup_config(m, host)

            print("  🔄 Pushing configuration...")
            m.edit_config(target="running", config=config, default_operation="merge")

            print(f"  ✅ Push complete: {host}")
            log_action(host, "PUSH_SUCCESS", backup_file or "no-backup")
            return True

    except SessionCloseError as e:
        print(f"❌ Push failed: {host} → Device closed the NETCONF session")
        print(f"   This usually means the XML payload contains an element the device")
        print(f"   doesn't support or that is read-only (e.g. <type> on cEOS).")
        print(f"   Detail: {e}")
        log_action(host, "PUSH_FAILED_SESSION_CLOSE", str(e))
        return False

    except TimeoutExpiredError as e:
        print(f"❌ Push failed: {host} → NETCONF timeout (device too slow or unresponsive)")
        log_action(host, "PUSH_FAILED_TIMEOUT", str(e))
        return False

    except Exception as e:
        print(f"❌ Push failed: {host} → {e}")
        log_action(host, "PUSH_FAILED", str(e))
        return False


# ─────────────────────────────────────────
# ROLLBACK
# ─────────────────────────────────────────

def rollback_config(host, username, password, backup_file):
    """
    Restore a device to a previously backed-up state.

    Key design:
      nc:operation="replace" is injected on each <interface> element (not on
      the top-level <config>).  This means:
        - Each interface block is fully replaced, restoring deleted attributes
          like <description> that a plain merge would not restore.
        - Interfaces not mentioned in the backup are left alone.
        - We never wipe unrelated config (routing, management, etc).

    Arista cEOS  → replace each OpenConfig <interface>
    Cisco CSR    → replace the <interface> container inside <native>
    """
    ensure_backup_dir()

    if not backup_file.startswith("/"):
        backup_file = os.path.join(BACKUP_DIR, backup_file)

    if not os.path.exists(backup_file):
        print(f"❌ Backup file not found: {backup_file}")
        return False

    with open(backup_file) as f:
        config = f.read()

    print(f"\n⏮️  ROLLBACK → {host}")
    print(f"  📦 Backup: {os.path.basename(backup_file)}")

    try:
        with connect(host, username, password) as m:
            print("  🔒 Locking running datastore...")
            m.lock(target="running")

            success = False
            try:
                print("  🔄 Applying rollback...")

                if is_cisco(host):
                    # Replace the whole <interface> container inside <native>
                    # This replaces all interface sub-elements (GigabitEthernet etc.)
                    config = re.sub(
                        r"(<interface>)",
                        '<interface nc:operation="replace">',
                        config,
                    )
                else:
                    # Replace each individual OpenConfig <interface> block
                    # so each interface is fully restored from backup
                    config = re.sub(
                        r"(<interface>)",
                        '<interface nc:operation="replace">',
                        config,
                    )

                m.edit_config(
                    target="running",
                    config=config,
                    default_operation="merge",
                )
                success = True

            except SessionCloseError as e:
                print(f"  ❌ Device closed the session during rollback: {e}")
                print(f"     The backup payload may contain read-only elements.")
                success = False

            except Exception as rpc_err:
                msg = str(rpc_err)
                # cEOS sometimes sends a non-fatal warning RPC reply on replace ops
                if "rpc-reply" in msg or "does not meet requirement" in msg:
                    print("  ⚠️  Non-fatal NETCONF warning received (config was applied)")
                    success = True
                else:
                    print(f"  ❌ RPC error during rollback: {rpc_err}")
                    success = False
            finally:
                try:
                    print("  🔓 Unlocking running datastore...")
                    m.unlock(target="running")
                except Exception:
                    pass  # If session is gone, unlock will fail — that's fine

            if success:
                print(f"  ✅ Rollback complete: {host}")
                log_action(host, "ROLLBACK_SUCCESS", os.path.basename(backup_file))
                return True
            else:
                log_action(host, "ROLLBACK_FAILED", os.path.basename(backup_file))
                return False

    except SessionCloseError as e:
        print(f"❌ Rollback connection closed unexpectedly: {host} → {e}")
        log_action(host, "ROLLBACK_FAILED_SESSION_CLOSE", str(e))
        return False

    except Exception as e:
        print(f"❌ Rollback failed: {host} → {e}")
        log_action(host, "ROLLBACK_FAILED", str(e))
        return False


# ─────────────────────────────────────────
# LIST BACKUPS
# ─────────────────────────────────────────

def list_backups(host=None):
    ensure_backup_dir()
    files = sorted(
        [
            f for f in os.listdir(BACKUP_DIR)
            if "_backup_" in f and (host is None or host in f)
        ],
        reverse=True,
    )
    if not files:
        print("❌ No backups found.")
        return
    print("\n📋 Available backups:")
    for i, fname in enumerate(files, 1):
        path = os.path.join(BACKUP_DIR, fname)
        size = os.path.getsize(path)
        mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S")
        print(f"  {i:2}. {fname}  ({size} bytes, {mtime})")


# ─────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  push     <host> <user> <pass> <xml_file>")
        print("  rollback <host> <user> <pass> <backup_file>")
        print("  list     [host]")
        sys.exit(1)

    action = sys.argv[1]

    if action == "push":
        ok = push_config(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        sys.exit(0 if ok else 1)

    elif action == "rollback":
        ok = rollback_config(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        sys.exit(0 if ok else 1)

    elif action == "list":
        host_filter = sys.argv[2] if len(sys.argv) > 2 else None
        list_backups(host_filter)

    else:
        print(f"Unknown action: {action}")
        sys.exit(1)