#!/bin/bash

# Setup script for NETCONF + YANG automation environment

set -e

echo "=== Setting up Python Virtual Environment ==="

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

echo "✓ Virtual environment created and activated"

# Upgrade pip
pip install --upgrade pip

# Install requirements
pip install -r requirements.txt

# Install Ansible NETCONF collection
ansible-galaxy collection install ansible.netcommon
ansible-galaxy collection install arista.eos

echo "=== Setup Complete ==="
echo ""
echo "To activate the environment in future sessions, run:"
echo "  source venv/bin/activate"
echo ""
echo "To run playbooks:"
echo "  ansible-playbook -i inventory.ini playbooks/configure-nodes.yml"
