"""
Custom Ansible filter plugins for network automation.
"""
import ipaddress



def pfx_to_mask(prefix_length):
    """Convert a prefix length (int) to a dotted-decimal subnet mask."""
    net = ipaddress.IPv4Network(f"0.0.0.0/{prefix_length}")
    return str(net.netmask)


class FilterModule:
    def filters(self):
        return {
            "pfx_to_mask": pfx_to_mask,
        }
